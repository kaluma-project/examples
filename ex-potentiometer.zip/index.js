var pin = 26; // ADC0
var value = 0;

setInterval(function () {
  var p = analogRead(pin);
  var delta = Math.abs(value - p);
  if (delta > 0.01) {
    value = p;
    console.log(value);
  }
}, 100);

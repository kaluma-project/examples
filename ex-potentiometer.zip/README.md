# Overview

This example shows how to read analog value with a potentiometer.

# Components

| Part              | Quantity  | Note | 
| ----------------- | --------- | ---- |
| Raspberry Pi Pico | 1         |      |
| Breadboard        | 1         | Half-size  |
| Potentiometer     | 1         |      |
| Jumper wires      |           |      |

# Wiring

| Raspberry Pi Pico | Potentiometer | 
| ----------------- | ------------- |
| GND               | -             |
| 3V3               | +             |
| GP26 (ADC0)       | OUT (middle)  |

![1616646511845.png](/api/projects/kaluma/ex-potentiometer/photos/1616646511845.png)

# Code

It reads potentiometer value using `analogRead()` every 0.1 seconds and print the value on the console only if the value is changed over than 0.1.

```js
var pin = 26; // ADC0
var value = 0;

setInterval(function () {
  var p = analogRead(pin);
  var delta = Math.abs(value - p);
  if (delta > 0.01) {
    value = p;
    console.log(value);
  }
}, 100);
```

# See also

- [analogRead()](https://docs.kaluma.io/api-reference/analog_io#analogread)
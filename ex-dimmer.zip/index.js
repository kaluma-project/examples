var led = 15;
var po = 26; // potentiometer

setInterval(function () {
  var val = analogRead(po);
  analogWrite(led, val);
}, 100);

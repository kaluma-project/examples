# Overview

A LED dimmer example with potentiometer.

# Components

| Part              | Quantity  | Note | 
| ----------------- | --------- | ---- |
| Raspberry Pi Pico | 1         |      |
| Breadboard        | 1         | Half-size  |
| LED               | 1         | red  |
| Resistor          | 1         | 330 Ohm |
| Potentiometer     | 1         |      |
| Jumper wires      |           |      |

# Wiring

| Raspberry Pi Pico | LED     | Resistor | Potentiometer |
| ----------------- | ------- | -------- | ------------- |
| 3V3               |         |          | +             |
| GND               | cathode |          | -             |
|                   | anode   | any      |               |
| GP15              |         | any      |               |
| GP26 (ACD0)       |         |          | OUT (middle)  |

![1616648372405.png](/api/projects/kaluma/ex-dimmer/photos/1616648372405.png)

# Code

This code reads analog value from the potentiometer and set the brightness of the LED.

```js
var led = 15;
var po = 26; // potentiometer

setInterval(function () {
  var val = analogRead(po);
  analogWrite(led, val);
}, 100);
```

# See also

- [analogRead()](https://docs.kaluma.io/api-reference/analog_io#analogread)
- [analogWrite()](https://docs.kaluma.io/api-reference/analog_io#analogwrite)
- [setInterval()](https://docs.kaluma.io/api-reference/timers#setinterval)
# Overview

A blink example for Raspberry Pi Pico.

# Code

Turn on and off the on-board LED for every seconds.

```js
var led = 25;
pinMode(led, OUTPUT);
setInterval(() => {
  digitalToggle(led);
}, 1000);
```

# See also

- [pinMode()](https://docs.kaluma.io/api-reference/digital_io#pinmode)
- [digitalToggle()](https://docs.kaluma.io/api-reference/digital_io#digitaltoggle)
- [setInterval()](https://docs.kaluma.io/api-reference/timers#setinterval)

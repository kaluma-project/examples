var pin = 15;
pinMode(pin, OUTPUT);
digitalWrite(pin, HIGH);


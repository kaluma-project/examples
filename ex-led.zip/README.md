# Overview

An example to turn on the external LED.

# Components

| Part              | Quantity  | Note | 
| ----------------- | --------- | ---- |
| Raspberry Pi Pico | 1         |      |
| Breadboard        | 1         | Half-size  |
| LED               | 1         | red  |
| Resistor          | 1         | 330 Ohm |
| Jumper wires      |           |      |

# Wiring

| Raspberry Pi Pico | LED     | Resistor |
| ----------------- | ------- | -------- |
| GND               | cathode |          |
|                   | anode   | any      |
| GP15              |         | any      |

![1616490527733.png](/api/projects/kaluma/ex-led/photos/1616490527733.png)

# Code

Turn on the LED connected to the GP15 pin.

```js
var pin = 15;
pinMode(pin, OUTPUT);
digitalWrite(pin, HIGH);
```

# See also

- [pinMode()](https://docs.kaluma.io/api-reference/digital_io#pinmode)
- [digitalWrite()](https://docs.kaluma.io/api-reference/digital_io#digitalwrite)
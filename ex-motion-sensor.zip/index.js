var pir = 28; // PIR (GP28)
var led = 15; // LED (GP15)

pinMode(pir, INPUT);
pinMode(led, OUTPUT);

setInterval(function () {
  var motion = digitalRead(pir);
  if (motion === HIGH) {
    digitalWrite(led, HIGH);
  } else {
    digitalWrite(led, LOW);
  }
}, 100);

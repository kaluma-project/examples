var r = 0; // GP0
var g = 2; // GP1
var b = 4; // GP2

function setColor(red, green, blue) {
  analogWrite(r, red);
  analogWrite(g, green);
  analogWrite(b, blue);
}

setInterval(() => {
  var rv = Math.random();
  var gv = Math.random();
  var bv = Math.random();
  setColor(rv, gv, bv);
  console.log(`random color: r=${rv.toFixed(2)},g=${gv.toFixed(2)},b=${bv.toFixed(2)}`);
}, 1000);

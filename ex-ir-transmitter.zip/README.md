# Overview

This example shows how to transmit IR signals read from a remote controller.

# Components

| Part              | Quantity  | Note | 
| ----------------- | --------- | ---- |
| Raspberry Pi Pico | 1         |      |
| Breadboard        | 1         | mini |
| Push button       | 1         |      |
| IR LED            | 1         | 940nm  |
| IR receiver       | 1         | TSOP38438 (or TSOP1838) 38KHz |
| Remote controller | 1         | NEC type (38KHz) |
| Jumper wires      |           |      |

# Wiring

| Raspberry Pi Pico | IR receiver | IR LED  | Button |
| ----------------- | ----------- | ------- | ------ |
| 3V3               | VCC         |         | L1     |
| GND               | GND         |         |        |
| GP15              | OUT         |         |        |
| GP16              |             | anode   |        |
| GP17              |             | cathode |        |
| GP14              |             |         | L2     |

![1618922444174.jpg](/api/projects/kaluma/ex-ir-transmitter/photos/1618922444174.jpg)

# Code

When you send IR signal to the IR receiver using a remote controller (38KHz), the signal pulse is stored in the `memory` variable. Then, it sends the stored IR signal whenever you press the button.

```js
var IRReceiver = require('@kaluma/ir-receiver').IRReceiver;

var memory = null;  // to store received IR signal
var recv = 15;      // pin for IR receiver
var led_pulse = 16; // pin for IR LED digital pulse
var led_pwm = 17;   // pin for IR LED 38KHz carrier
var btn = 14;       // pin for button

pinMode(recv, INPUT_PULLUP);
pinMode(led_pulse, OUTPUT);
pinMode(btn, INPUT_PULLDOWN);

// receive IR signal and save to memory
var ir = new IRReceiver(recv);
ir.on('data', (data, bits, pulse) => {
  console.log('IR signal received.');
  console.log(`- data: ${data.toString(16)} (${bits} bits)`);
  console.log(`- pulse(${pulse.length}): [${pulse.join(',')}]`);
  memory = pulse;
});

// send IR signal stored in memory
function send() {
  analogWrite(led_pwm, 0.5, 38000); // 38KHz
  pulseWrite(led_pulse, HIGH, memory);
  digitalWrite(led_pulse, LOW);
  console.log('Sent IR signal.');
}

// send signal when button pressed
setWatch(send, btn, RISING, 10);
```

# See also

- [@kaluma/ir-receiver](https://kaluma.io/@kaluma/ir-receiver)

# References

- https://learn.adafruit.com/using-an-infrared-library/sending-ir-codes
- https://www.raspberry-pi-geek.com/Archive/2015/10/Raspberry-Pi-IR-remote

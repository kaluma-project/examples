# Overview

An example to detect brightness using a photocell.

# Components

| Part              | Quantity  | Note | 
| ----------------- | --------- | ---- |
| Raspberry Pi Pico | 1         |      |
| Breadboard        | 1         | Half-size  |
| Resistor          | 1         | 10K Ohm |
| Photocell         | 1         | CdS     |
| Jumper wires      |           |      |

# Wiring

| Raspberry Pi Pico | Photocell | Resistor |
| ----------------- | --------- | -------- |
| 3V3               | L1        |          |
| GP26              | L2        | L1       |
| GND               |           | L2       |

![1617076891528.jpg](/api/projects/kaluma/ex-photocell/photos/1617076891528.jpg)

# Code

This code reads analog value from a photocell and print in console on every seconds.

```js
var pin = 26; // ADC0
setInterval(() => {
  var value = analogRead(pin);
  console.log(value);
}, 1000);
```

# See also

- [analogRead()](https://docs.kaluma.io/api-reference/analog_io#analogread)
- [setInterval()](https://docs.kaluma.io/api-reference/timers#setinterval)

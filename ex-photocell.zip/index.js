var pin = 26; // ADC0
setInterval(() => {
  var value = analogRead(pin);
  console.log(value);
}, 1000);
